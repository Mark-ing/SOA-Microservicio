package com.SOA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionProyectoApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionProyectoApplication.class, args);
	}

}
