package com.SOA.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SOA.entidad.Rol_Equipo;

public interface Rol_EquipoRepository extends JpaRepository<Rol_Equipo, Integer>{

}
