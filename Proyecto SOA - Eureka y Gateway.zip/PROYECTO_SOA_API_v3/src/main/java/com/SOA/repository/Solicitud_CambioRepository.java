package com.SOA.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SOA.entidad.Solicitud_Cambio;

public interface Solicitud_CambioRepository extends JpaRepository<Solicitud_Cambio, Integer>{

}
