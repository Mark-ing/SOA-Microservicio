package com.SOA.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SOA.entidad.Equipo;

public interface EquipoRepository extends JpaRepository<Equipo, Integer>{

}
