package com.SOA.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SOA.entidad.Proyecto;

public interface ProyectoRepository extends JpaRepository<Proyecto, Integer>{

}
