package com.SOA.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SOA.entidad.Documento;

public interface DocumentoRepository extends JpaRepository<Documento, Integer>{

}
