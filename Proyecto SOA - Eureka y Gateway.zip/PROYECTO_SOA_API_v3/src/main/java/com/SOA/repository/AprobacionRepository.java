package com.SOA.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SOA.entidad.Aprobacion;

public interface AprobacionRepository extends JpaRepository<Aprobacion, Integer>{

}
