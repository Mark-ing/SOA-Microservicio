package com.SOA.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SOA.entidad.Jefe_Proyecto;

public interface Jefe_ProyectoRepository extends JpaRepository<Jefe_Proyecto, Integer>{

}
