package com.SOA.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SOA.entidad.Jefe_Area;

public interface Jefe_AreaRepository extends JpaRepository<Jefe_Area, Integer>{

}
