package com.SOA.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SOA.entidad.Usuarios_Sesiones;

public interface Usuarios_SesionesRepository extends JpaRepository<Usuarios_Sesiones, Integer>{

}
