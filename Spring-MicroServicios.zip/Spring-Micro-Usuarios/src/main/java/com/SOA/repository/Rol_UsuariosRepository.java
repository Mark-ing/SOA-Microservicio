package com.SOA.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.SOA.entidad.Rol_Usuarios;

public interface Rol_UsuariosRepository extends JpaRepository<Rol_Usuarios, Integer>{

}
